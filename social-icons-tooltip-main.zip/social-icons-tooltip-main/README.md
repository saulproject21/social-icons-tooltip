# Social Icons Tooltip
## [Watch it on youtube](https://youtu.be/C03eRxMrYB0)
### Social Icons Tooltip
Beautiful icons of social networks with tooltips when hovering the mouse, each icon integrates a tooltip towards a direction in left, top, right and bottom.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
